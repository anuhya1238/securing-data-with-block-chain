import mysql.connector

con = mysql.connector.connect(host='localhost',port = 3306,user = 'root', password = '', database = 'SecuringData',charset='utf8')
cur = con.cursor()
cur.execute("select * FROM patients")
rows = cur.fetchall()
for i in rows:
	print(i)